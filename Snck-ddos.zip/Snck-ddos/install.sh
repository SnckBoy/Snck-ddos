#!/usr/bin/env bash
# Snck-ddos one-command installer
# Usage: curl -fsSL https://raw.githubusercontent.com/SnckBoy/Snck-ddos/main/install.sh | bash
set -euo pipefail

REPO="https://github.com/SnckBoy/Snck-ddos.git"
DIR="${HOME}/Snck-ddos"
PYTHON="${PYTHON:-python3}"

echo "[*] Snck-ddos installer"
echo "[*] target dir: ${DIR}"

if ! command -v git >/dev/null 2>&1; then
  echo "[!] git required — install git and re-run"
  exit 1
fi

if ! command -v "${PYTHON}" >/dev/null 2>&1; then
  echo "[!] python3 required"
  exit 1
fi

if [ -d "${DIR}/.git" ]; then
  echo "[*] existing clone — pulling latest"
  git -C "${DIR}" pull --ff-only || true
else
  echo "[*] cloning..."
  git clone --depth 1 "${REPO}" "${DIR}"
fi

cd "${DIR}"

echo "[*] creating venv..."
"${PYTHON}" -m venv .venv
# shellcheck disable=SC1091
source .venv/bin/activate

echo "[*] installing deps..."
pip install --upgrade pip -q
pip install -r requirements.txt -q

# seed empty proxy files
touch proxies.txt live_proxies.txt

echo ""
echo "[✓] installed"
echo ""
echo "  start:   cd ${DIR} && source .venv/bin/activate && python main.py"
echo "  panel:   http://0.0.0.0:6666"
echo ""
echo "  one-liner after install:"
echo "  cd ${DIR} && source .venv/bin/activate && python main.py"
echo ""
