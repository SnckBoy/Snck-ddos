#!/usr/bin/env bash
# Snck-ddos one-command installer
# Repo currently hosts Snck-ddos.zip — this script downloads + extracts it
set -euo pipefail

REPO_ZIP="https://raw.githubusercontent.com/SnckBoy/Snck-ddos/main/Snck-ddos.zip"
DIR="${HOME}/Snck-ddos"
PYTHON="${PYTHON:-python3}"

echo "[*] Snck-ddos installer"
echo "[*] install dir: ${DIR}"

for bin in curl unzip "$PYTHON"; do
  if ! command -v "$bin" >/dev/null 2>&1; then
    echo "[!] missing: $bin"
    exit 1
  fi
done

rm -rf "${DIR}"
mkdir -p "${DIR}"
cd /tmp

echo "[*] downloading..."
curl -fsSL "${REPO_ZIP}" -o Snck-ddos.zip

echo "[*] extracting..."
rm -rf Snck-ddos-extract
mkdir Snck-ddos-extract
unzip -q Snck-ddos.zip -d Snck-ddos-extract

# zip root is Snck-ddos/
if [ -d Snck-ddos-extract/Snck-ddos ]; then
  cp -a Snck-ddos-extract/Snck-ddos/. "${DIR}/"
else
  cp -a Snck-ddos-extract/. "${DIR}/"
fi
rm -rf Snck-ddos.zip Snck-ddos-extract

cd "${DIR}"

if [ ! -f main.py ]; then
  echo "[!] main.py missing after extract"
  ls -la
  exit 1
fi

echo "[*] creating venv..."
"${PYTHON}" -m venv .venv
# shellcheck disable=SC1091
source .venv/bin/activate

echo "[*] installing packages..."
pip install --upgrade pip -q
pip install -r requirements.txt -q

touch proxies.txt live_proxies.txt
chmod +x main.py install.sh 2>/dev/null || true

echo ""
echo "[✓] Snck-ddos ready"
echo ""
echo "  start:"
echo "    cd ${DIR} && source .venv/bin/activate && python main.py"
echo ""
echo "  panel: http://0.0.0.0:6666"
echo ""
